﻿# SpringBootCrudPatterns

Depois que levantar a aplicação abra o browser e coloque essas urls para ver o programa funcionando
http://localhost:8080/usuarios
Para acessar o banco de dados
http://localhost:8080/h2-console

Bando de dados PostGresSQL
Olhe no Properties.
A ideia e a integração de um CRUD com uma função sendo refatorada para um design patterns.
