package com.finan.orcamento.controller;

import org.springframework.ui.Model;
import com.finan.orcamento.model.FornecedorModel;
import com.finan.orcamento.service.FornecedorService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/fornecedores")
public class FornecedorController {

    private final FornecedorService fornecedorService;

    public FornecedorController(FornecedorService fornecedorService) {
        this.fornecedorService = fornecedorService;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("fornecedores", fornecedorService.listar());
        model.addAttribute("fornecedor", new FornecedorModel()); // ESSENCIAL
        return "fornecedorPage";
    }

    @PostMapping
    public String salvar(@ModelAttribute FornecedorModel fornecedor) {
        fornecedorService.salvar(fornecedor);
        return "redirect:/fornecedores";
    }
}