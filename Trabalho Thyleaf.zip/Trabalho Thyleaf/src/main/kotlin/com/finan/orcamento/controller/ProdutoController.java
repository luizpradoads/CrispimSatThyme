package com.finan.orcamento.controller;


import com.finan.orcamento.model.ProdutoModel;
import com.finan.orcamento.service.FornecedorService;
import com.finan.orcamento.service.ProdutoService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/produtos")
public class ProdutoController {

    private final ProdutoService produtoService;
    private final FornecedorService fornecedorService;

    public ProdutoController(ProdutoService produtoService, FornecedorService fornecedorService) {
        this.produtoService = produtoService;
        this.fornecedorService = fornecedorService;
    }

    @PostMapping
    public String salvar(@ModelAttribute ProdutoModel produto) {
        produtoService.salvar(produto);
        return "redirect:/fornecedores";
    }
}