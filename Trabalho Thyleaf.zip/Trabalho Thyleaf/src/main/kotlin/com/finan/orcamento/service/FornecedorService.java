package com.finan.orcamento.service;


import com.finan.orcamento.model.FornecedorModel;
import com.finan.orcamento.repositories.FornecedorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FornecedorService {

    private final FornecedorRepository fornecedorRepository;

    public FornecedorService(FornecedorRepository fornecedorRepository) {
        this.fornecedorRepository = fornecedorRepository;
    }

    public FornecedorModel salvar(FornecedorModel fornecedor) {
        return fornecedorRepository.save(fornecedor);
    }

    public List<FornecedorModel> listar() {
        return fornecedorRepository.findAll();
    }

    public FornecedorModel buscarPorId(Long id) {
        return fornecedorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Fornecedor não encontrado com ID: " + id));
    }
}