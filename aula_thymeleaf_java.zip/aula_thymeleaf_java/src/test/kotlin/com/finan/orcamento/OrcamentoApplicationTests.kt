package com.finan.orcamento

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class OrcamentoApplicationTests {

	@Test
	fun contextLoads() {
	}

}
